// Minimal static Scorekeeper with Firestore (compat) and localStorage fallback
(function(){
  const firebaseConfig = {
    apiKey: "AIzaSyCkvl2kGeuLuDrIFT8UdeLvBYPXHVwr9ck",
    authDomain: "the-choke-ledger.firebaseapp.com",
    projectId: "the-choke-ledger"
  };

  const LOCAL_KEY = 'scorekeeper.players';
  const statusEl = () => document.getElementById('status');
  const listEl = () => document.getElementById('list');

  function setStatus(s){ const el = statusEl(); if(el) el.textContent = 'Status: '+s; }
  function makeId(){ return 'local-'+(Date.now().toString(36)+Math.floor(Math.random()*1000).toString(36)) }

  // local players structure: [{id,name,misses,createdAt}]
  function loadLocal(){ try{ const raw = localStorage.getItem(LOCAL_KEY); return raw? JSON.parse(raw): []; }catch(e){ console.error(e); return []; } }
  function saveLocal(players){ try{ localStorage.setItem(LOCAL_KEY, JSON.stringify(players)); }catch(e){ console.error(e); } }

  // UI helpers
  function render(players){ const ul = listEl(); if(!ul) return; ul.innerHTML = ''; players.forEach(p=>{
    const li = document.createElement('li'); li.className='item';
    li.innerHTML = `<div><div class="name">${escapeHtml(p.name)}</div><div class="sub">${(p.misses||0)} misses — $${(p.misses||0)}</div></div>`;
    const controls = document.createElement('div'); controls.className='controls';
    const dec = document.createElement('button'); dec.textContent='−'; dec.onclick=()=> decPlayer(p.id);
    const inc = document.createElement('button'); inc.textContent='+'; inc.onclick=()=> incPlayer(p.id);
    const rm = document.createElement('button'); rm.textContent='✕'; rm.className='rm'; rm.onclick=()=> removePlayer(p.id);
    controls.appendChild(dec); controls.appendChild(inc); controls.appendChild(rm);
    li.appendChild(controls);
    ul.appendChild(li);
  })}

  function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') }

  // local store
  let players = loadLocal();
  render(players);
  setStatus('ready (local)');

  // wire UI
  document.getElementById('addBtn').addEventListener('click', addPlayerFromInput);
  document.getElementById('resetBtn').addEventListener('click', resetAll);
  document.getElementById('exportBtn').addEventListener('click', exportCSV);
  document.getElementById('nameInput').addEventListener('keydown', e=>{ if(e.key==='Enter') addPlayerFromInput(); });

  function addPlayerFromInput(){ const input = document.getElementById('nameInput'); const name = input.value.trim(); if(!name) return; input.value=''; addPlayer(name); }

  function addPlayer(name){ const p = { id: makeId(), name, misses:0, createdAt: Date.now() }; players.push(p); saveLocal(players); render(players); if(window.appFirestoreReady){ pushToFirestore(p).then(id=>{ if(id){ // replace local id
        players = players.map(x=> x.id===p.id? {...x,id}: x ); saveLocal(players); render(players);
      }}).catch(e=>console.error('push failed',e)); } }

  function incPlayer(id){ players = players.map(p=> p.id===id? {...p,misses:(p.misses||0)+1}: p); saveLocal(players); render(players); if(window.appFirestoreReady && !String(id).startsWith('local-')) updateFirestore(id,{ misses: players.find(p=>p.id===id).misses }); }
  function decPlayer(id){ players = players.map(p=> p.id===id? {...p,misses:Math.max(0,(p.misses||0)-1)}: p); saveLocal(players); render(players); if(window.appFirestoreReady && !String(id).startsWith('local-')) updateFirestore(id,{ misses: players.find(p=>p.id===id).misses }); }
  function removePlayer(id){ players = players.filter(p=> p.id!==id); saveLocal(players); render(players); if(window.appFirestoreReady && !String(id).startsWith('local-')) deleteFirestore(id); }
  function resetAll(){ if(!confirm('Reset all scores to 0?')) return; players = players.map(p=> ({ ...p, misses:0 })); saveLocal(players); render(players); if(window.appFirestoreReady){ players.forEach(p=>{ if(!String(p.id).startsWith('local-')) updateFirestore(p.id,{ misses:0 }); }); } }

  function exportCSV(){ let csv='Name,Misses,Amount\n'; players.forEach(p=>{ csv += '"'+String(p.name).replace(/"/g,'""')+'",'+(p.misses||0)+','+(p.misses||0)+'\n'; }); const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='scores.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href); }

  // Firestore integration (compat SDK loaded via script tag)
  async function initFirestore(){
    try{
      if(!window.firebase || !firebase.firestore){ setStatus('Firestore SDK not loaded'); return; }
      firebase.initializeApp(firebaseConfig);
      const db = firebase.firestore();
      window.appFirestore = db;
      window.appFirestoreReady = true;
      setStatus('connected to Firestore');

      // listen for remote changes
      db.collection('players').orderBy('createdAt').onSnapshot(snap=>{
        const items = [];
        snap.forEach(d=>{
          const data = d.data(); items.push({ id: d.id, name: data.name, misses: data.misses||0, createdAt: data.createdAt||Date.now() });
        });
        // merge: prefer server items but keep local unsynced ones
        const localOnly = players.filter(p=> String(p.id).startsWith('local-'));
        players = [...items, ...localOnly];
        saveLocal(players);
        render(players);
      }, err=>{ console.error('snapshot err',err); setStatus('Firestore snapshot error'); });

      // attempt to migrate any local-only entries
      const localOnly = players.filter(p=> String(p.id).startsWith('local-'));
      for(const p of localOnly){ try{ const r = await db.collection('players').add({ name:p.name, misses:p.misses||0, createdAt:p.createdAt||Date.now() }); console.log('migrated',p.name,'->',r.id); // replace id
          players = players.map(x=> x.id===p.id? { ...x, id: r.id }: x ); saveLocal(players); render(players);
        }catch(e){ console.error('migrate failed',e); }
      }

    }catch(e){ console.error('initFirestore failed', e); setStatus('Firestore init failed'); }
  }

  function pushToFirestore(p){ return new Promise(async (resolve,reject)=>{
    try{ const r = await window.appFirestore.collection('players').add({ name:p.name, misses:p.misses||0, createdAt:p.createdAt||Date.now() }); resolve(r.id); }catch(e){ reject(e);} }); }
  function updateFirestore(id,patch){ return window.appFirestore.collection('players').doc(id).update(patch); }
  function deleteFirestore(id){ return window.appFirestore.collection('players').doc(id).delete(); }

  // attempt to initialize Firestore after SDKs load
  function tryInit(){ if(window.firebase && firebase.firestore){ initFirestore(); } else { // wait and retry
      setStatus('waiting for Firestore SDK...'); setTimeout(tryInit, 800);
    } }
  tryInit();
})();