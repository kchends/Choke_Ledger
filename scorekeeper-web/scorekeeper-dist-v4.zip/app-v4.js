// REST-only Scorekeeper app bundle v4
(function(){
  const API_KEY = 'AIzaSyCkvl2kGeuLuDrIFT8UdeLvBYPXHVwr9ck';
  const PROJECT = 'the-choke-ledger';
  const DB_ID = 'choke';
  const LOCAL_KEY = 'scorekeeper.players';

  function setStatus(s){ const el=document.getElementById('status'); if(el) el.textContent='Status: '+s; }
  function loadLocal(){ try{ const raw=localStorage.getItem(LOCAL_KEY); return raw?JSON.parse(raw):[] }catch(e){console.error(e);return[]} }
  function saveLocal(p){ try{ localStorage.setItem(LOCAL_KEY, JSON.stringify(p)) }catch(e){console.error(e)} }
  function makeId(){ return 'local-'+(Date.now().toString(36)+Math.floor(Math.random()*1000).toString(36)) }
  function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') }

  function render(players){ const ul=document.getElementById('list'); if(!ul) return; ul.innerHTML=''; players.forEach(p=>{
    const li=document.createElement('li'); li.className='item';
    li.innerHTML = `<div><div class="name">${escapeHtml(p.name)}</div><div class="sub">${(p.misses||0)} misses — $${(p.misses||0)}</div></div>`;
    const controls=document.createElement('div'); controls.className='controls';
    const dec=document.createElement('button'); dec.textContent='−'; dec.onclick=()=>decPlayer(p.id);
    const inc=document.createElement('button'); inc.textContent='+'; inc.onclick=()=>incPlayer(p.id);
    const rm=document.createElement('button'); rm.textContent='✕'; rm.className='rm'; rm.onclick=()=>removePlayer(p.id);
    controls.appendChild(dec); controls.appendChild(inc); controls.appendChild(rm);
    li.appendChild(controls);
    ul.appendChild(li);
  }) }

  let players = loadLocal(); render(players); setStatus('ready (local)');

  document.getElementById('addBtn').addEventListener('click', ()=>{ const input=document.getElementById('nameInput'); const name=input.value.trim(); if(!name) return; input.value=''; addPlayer(name); });
  document.getElementById('resetBtn').addEventListener('click', resetAll);
  document.getElementById('exportBtn').addEventListener('click', exportCSV);
  document.getElementById('nameInput').addEventListener('keydown', e=>{ if(e.key==='Enter') { const name=e.target.value.trim(); if(name){ e.target.value=''; addPlayer(name); } } });

  function addPlayer(name){ const p={ id: makeId(), name, misses:0, createdAt: Date.now() }; players.push(p); saveLocal(players); render(players); createServerPlayer(p).then(newId=>{ if(newId){ players = players.map(x=> x.id===p.id? {...x, id:newId}: x); saveLocal(players); render(players); } }).catch(e=>console.error('create failed',e)); }

  function incPlayer(id){ players = players.map(p=> p.id===id? {...p, misses:(p.misses||0)+1}: p); saveLocal(players); render(players); if(!String(id).startsWith('local-')) updateServerPlayer(id,{ misses: players.find(p=>p.id===id).misses }).catch(e=>console.error(e)); }
  function decPlayer(id){ players = players.map(p=> p.id===id? {...p, misses:Math.max(0,(p.misses||0)-1)}: p); saveLocal(players); render(players); if(!String(id).startsWith('local-')) updateServerPlayer(id,{ misses: players.find(p=>p.id===id).misses }).catch(e=>console.error(e)); }
  function removePlayer(id){ players = players.filter(p=> p.id!==id); saveLocal(players); render(players); if(!String(id).startsWith('local-')) deleteServerPlayer(id).catch(e=>console.error(e)); }
  function resetAll(){ if(!confirm('Reset all scores to 0?')) return; players = players.map(p=> ({...p, misses:0})); saveLocal(players); render(players); players.forEach(p=>{ if(!String(p.id).startsWith('local-')) updateServerPlayer(p.id,{ misses:0 }).catch(e=>console.error(e)); }); }
  function exportCSV(){ let csv='Name,Misses,Amount\n'; players.forEach(p=>{ csv += '"'+String(p.name).replace(/"/g,'""')+'",'+(p.misses||0)+','+(p.misses||0)+'\n'; }); const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='scores.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href); }

  // REST helpers
  function docIdFromName(name){ const parts=name.split('/'); return parts[parts.length-1]; }
  function parseDoc(doc){ const data=doc.fields||{}; return { id: docIdFromName(doc.name), name: (data.name && data.name.stringValue) || '', misses: data.misses && parseInt(data.misses.integerValue||'0')||0, createdAt: data.createdAt && parseInt(data.createdAt.integerValue||String(Date.now()))||Date.now() }; }

  async function listServerPlayers(){ try{ const url = 'https://firestore.googleapis.com/v1/projects/' + PROJECT + '/databases/' + DB_ID + '/documents/players?key=' + API_KEY; const res=await fetch(url); if(!res.ok){ const txt=await res.text(); throw new Error('list failed: '+res.status+' '+txt); } const json=await res.json(); if(!json.documents) return []; return json.documents.map(parseDoc); }catch(e){ console.error('listServerPlayers error', e); return null; } }
  async function createServerPlayer(p){ try{ const url='https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players?key='+API_KEY; const body={ fields: { name:{ stringValue: String(p.name) }, misses:{ integerValue: String(p.misses||0) }, createdAt:{ integerValue: String(p.createdAt||Date.now()) } } }; const res=await fetch(url,{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) }); const txt=await res.text(); if(!res.ok) throw new Error('create failed: '+res.status+' '+txt); const json=JSON.parse(txt); return docIdFromName(json.name); }catch(e){ console.error('createServerPlayer error', e); return null; } }
  async function updateServerPlayer(id,patch){ try{ const url='https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players/'+id+'?key='+API_KEY; const bodyFields={}; if(patch.misses!==undefined) bodyFields.misses={ integerValue: String(patch.misses) }; if(patch.name!==undefined) bodyFields.name={ stringValue: String(patch.name) }; const res=await fetch(url,{ method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ fields: bodyFields }) }); if(!res.ok){ const txt=await res.text(); throw new Error('update failed: '+res.status+' '+txt); } return true; }catch(e){ console.error('updateServerPlayer error', e); return false; } }
  async function deleteServerPlayer(id){ try{ const url='https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players/'+id+'?key='+API_KEY; const res=await fetch(url,{ method:'DELETE' }); if(!res.ok){ const txt=await res.text(); throw new Error('delete failed: '+res.status+' '+txt); } return true; }catch(e){ console.error('deleteServerPlayer error', e); return false; } }

  // initial sync and poll
  (async function init(){ const server = await listServerPlayers(); if(server===null){ setStatus('Firestore REST unreachable'); } else { setStatus('connected to Firestore (REST)'); const localOnly = players.filter(p=> String(p.id).startsWith('local-')); players = [...server, ...localOnly]; saveLocal(players); render(players); for(const p of localOnly){ const newId = await createServerPlayer(p); if(newId){ players = players.map(x=> x.id===p.id? {...x, id:newId}: x); saveLocal(players); render(players); } } setInterval(async ()=>{ const s = await listServerPlayers(); if(s && Array.isArray(s)){ const localOnly2 = players.filter(p=> String(p.id).startsWith('local-')); players = [...s, ...localOnly2]; saveLocal(players); render(players); setStatus('connected to Firestore (REST)'); } }, 2000); } })();

})();