// REST-only Scorekeeper app bundle v4
(function(){
  const API_KEY = 'AIzaSyCkvl2kGeuLuDrIFT8UdeLvBYPXHVwr9ck';
  const PROJECT = 'the-choke-ledger';
  const DB_ID = 'choke';
  const LOCAL_KEY = 'scorekeeper.players';

  function setStatus(s){ const el=document.getElementById('status'); if(el) el.textContent='Status: '+s; }
  function loadLocal(){ try{ const raw=localStorage.getItem(LOCAL_KEY); return raw?JSON.parse(raw):[] }catch(e){console.error(e);return[]} }
  function saveLocal(p){ try{ localStorage.setItem(LOCAL_KEY, JSON.stringify(p)) }catch(e){console.error(e)} }
  function makeId(){ return 'local-'+(Date.now().toString(36)+Math.floor(Math.random()*1000).toString(36)) }
  function escapeHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;') }

  let editingId = null;

  function render(players){ const ul=document.getElementById('list'); if(!ul) return; ul.innerHTML='';
      // sort by misses desc, tie-breaker: highest dollar amount, then newest
      const sorted = (players||[]).slice().sort((a,b)=>{
        const ma = (a.misses||0);
        const mb = (b.misses||0);
        if(mb - ma !== 0) return mb - ma;
        const ama = (a.misses||0) * (a.skill||1);
        const amb = (b.misses||0) * (b.skill||1);
        if(amb - ama !== 0) return amb - ama;
        return (b.createdAt||0) - (a.createdAt||0);
      });
      // determine all top players (ties allowed) by misses then amount
      const topPlayers = [];
      if(sorted.length>0){ const bestMiss = sorted[0].misses||0; const bestAmount = (sorted[0].misses||0) * (sorted[0].skill||1);
        for(const sp of sorted){ if((sp.misses||0) === bestMiss && ((sp.misses||0)*(sp.skill||1)) === bestAmount){ topPlayers.push(sp.id); } else break; }
      }
      sorted.forEach(p=>{
        const li=document.createElement('li'); li.className='item';
        if(topPlayers.includes(p.id)) li.classList.add('mvp');
        const amount = (p.misses||0) * (p.skill||1);
        const safeName = escapeHtml(p.name || 'Unnamed');
        const badge = (topPlayers.includes(p.id)) ? '<span class="mvp-badge">👑 Supreme Choke</span>' : '';
        const infoDiv = document.createElement('div'); infoDiv.style.flex = '1';
        if(p.id === editingId){
          const nameInput = document.createElement('input'); nameInput.type = 'text'; nameInput.value = p.name || '';
          nameInput.style.padding = '8px'; nameInput.style.borderRadius = '6px'; nameInput.style.marginRight = '8px';
          const skillInput = document.createElement('input'); skillInput.type = 'number'; skillInput.min = '1'; skillInput.max = '9'; skillInput.value = p.skill || 1;
          skillInput.style.width = '80px'; skillInput.style.marginRight = '8px';
          const saveBtn = document.createElement('button'); saveBtn.textContent = 'Save'; saveBtn.onclick = ()=> saveEdit(p.id, nameInput.value, skillInput.value);
          const cancelBtn = document.createElement('button'); cancelBtn.textContent = 'Cancel'; cancelBtn.onclick = ()=> { editingId = null; render(players); };
          infoDiv.appendChild(nameInput); infoDiv.appendChild(skillInput); infoDiv.appendChild(saveBtn); infoDiv.appendChild(cancelBtn);
        } else {
          const nameDiv = document.createElement('div'); nameDiv.className='name'; nameDiv.innerHTML = safeName + badge;
          const subDiv = document.createElement('div'); subDiv.className='sub'; subDiv.textContent = 'Skill: ' + (p.skill||1) + ' — ' + (p.misses||0) + ' misses — $' + amount;
          infoDiv.appendChild(nameDiv); infoDiv.appendChild(subDiv);
        }
        li.appendChild(infoDiv);
        const controls=document.createElement('div'); controls.className='controls';
        const dec=document.createElement('button'); dec.type='button'; dec.textContent='−'; dec.onclick=()=>decPlayer(p.id);
        const inc=document.createElement('button'); inc.type='button'; inc.textContent='+'; inc.onclick=()=>incPlayer(p.id);
        const ed=document.createElement('button'); ed.type='button'; ed.textContent='✎'; ed.className='edit'; ed.onclick=()=>editPlayer(p.id);
        const rm=document.createElement('button'); rm.type='button'; rm.textContent='✕'; rm.className='rm'; rm.onclick=()=>removePlayer(p.id);
        controls.appendChild(dec); controls.appendChild(inc); controls.appendChild(ed); controls.appendChild(rm);
        li.appendChild(controls);
        ul.appendChild(li);
      }) }

  let players = loadLocal(); render(players); setStatus('ready (local)');

  document.getElementById('addBtn').addEventListener('click', ()=>{ const input=document.getElementById('nameInput'); const name=input.value.trim(); if(!name) return; input.value=''; addPlayer(name); });
  const resetBtnEl = document.getElementById('resetBtn'); if(resetBtnEl){ resetBtnEl.addEventListener('click', resetAll); /* removed from UI */ }
  const exportBtnEl = document.getElementById('exportBtn'); if(exportBtnEl){ exportBtnEl.addEventListener('click', exportCSV); }
  document.getElementById('nameInput').addEventListener('keydown', e=>{ if(e.key==='Enter') { const name=e.target.value.trim(); if(name){ e.target.value=''; addPlayer(name); } } });

  function addPlayer(name){ const skillInput = document.getElementById('skillInput'); let skill = 1; if(skillInput){ skill = parseInt(skillInput.value) || 1; skill = Math.max(1, Math.min(9, skill)); skillInput.value = ''; }
    const p={ id: makeId(), name, skill, misses:0, createdAt: Date.now() };
    players.push(p); saveLocal(players); render(players);
    createServerPlayer(p).then(newId=>{ if(newId){ players = players.map(x=> x.id===p.id? {...x, id:newId}: x); saveLocal(players); render(players); } }).catch(e=>console.error('create failed',e)); }

  function editPlayer(id){ editingId = id; render(players); }

    async function saveEdit(id,newName,newSkill){ const p = players.find(x=> x.id===id); if(!p) return; const old = { name: p.name, skill: p.skill };
      p.name = (newName||'').trim(); p.skill = Math.max(1, Math.min(9, Number(newSkill) || 1)); editingId = null; saveLocal(players); render(players); updateTotalAndChart(); if(String(p.id).startsWith('local-')){ setStatus('saved (local)'); return true; }
      try{ setStatus('saving...'); const ok = await updateServerPlayer(p.id,{ name: p.name, skill: p.skill }); if(ok){ setStatus('saved'); return true; } else { throw new Error('server returned failure'); } }catch(e){ console.error('edit failed', e); // revert
        p.name = old.name; p.skill = old.skill; saveLocal(players); render(players); updateTotalAndChart(); setStatus('save failed'); return false; } }

  function incPlayer(id){ players = players.map(p=> p.id===id? {...p, misses:(p.misses||0)+1}: p); saveLocal(players); render(players); if(!String(id).startsWith('local-')) updateServerPlayer(id,{ misses: players.find(p=>p.id===id).misses }).catch(e=>console.error(e)); }
  function decPlayer(id){ players = players.map(p=> p.id===id? {...p, misses:Math.max(0,(p.misses||0)-1)}: p); saveLocal(players); render(players); if(!String(id).startsWith('local-')) updateServerPlayer(id,{ misses: players.find(p=>p.id===id).misses }).catch(e=>console.error(e)); }
  function removePlayer(id){ players = players.filter(p=> p.id!==id); saveLocal(players); render(players); if(!String(id).startsWith('local-')) deleteServerPlayer(id).catch(e=>console.error(e)); }
  function resetAll(){ if(!confirm('Reset all scores to 0?')) return; players = players.map(p=> ({...p, misses:0})); saveLocal(players); render(players); players.forEach(p=>{ if(!String(p.id).startsWith('local-')) updateServerPlayer(p.id,{ misses:0 }).catch(e=>console.error(e)); }); }
  function exportCSV(){ let csv='Name,Skill,Misses,Amount\n'; players.forEach(p=>{ const amt = (p.misses||0) * (p.skill||1); csv += '"'+String(p.name).replace(/"/g,'""')+'",'+(p.skill||1)+','+(p.misses||0)+','+amt+'\n'; }); const blob=new Blob([csv],{type:'text/csv'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='scores.csv'; document.body.appendChild(a); a.click(); a.remove(); URL.revokeObjectURL(a.href); }

  // REST helpers
  function docIdFromName(name){ const parts=name.split('/'); return parts[parts.length-1]; }
  function parseDoc(doc){ const data=doc.fields||{}; return { id: docIdFromName(doc.name), name: (data.name && data.name.stringValue) ? data.name.stringValue : undefined, skill: (data.skill && parseInt(data.skill.integerValue||'1'))||1, misses: (data.misses && parseInt(data.misses.integerValue||'0'))||0, createdAt: (data.createdAt && parseInt(data.createdAt.integerValue||String(Date.now())))||Date.now() }; }

  async function listServerPlayers(){ try{ const url = 'https://firestore.googleapis.com/v1/projects/' + PROJECT + '/databases/' + DB_ID + '/documents/players?key=' + API_KEY; const res=await fetch(url); if(!res.ok){ const txt=await res.text(); throw new Error('list failed: '+res.status+' '+txt); } const json=await res.json(); if(!json.documents) return []; return json.documents.map(parseDoc); }catch(e){ console.error('listServerPlayers error', e); return null; } }
  async function createServerPlayer(p){ try{ const url='https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players?key='+API_KEY; const body={ fields: { name:{ stringValue: String((p.name && String(p.name).trim())? p.name : 'Unnamed') }, skill:{ integerValue: String(Math.max(1, Math.min(9, p.skill||1))) }, misses:{ integerValue: String(p.misses||0) }, createdAt:{ integerValue: String(p.createdAt||Date.now()) } } }; const res=await fetch(url,{ method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) }); const txt=await res.text(); if(!res.ok) throw new Error('create failed: '+res.status+' '+txt); const json=JSON.parse(txt); return docIdFromName(json.name); }catch(e){ console.error('createServerPlayer error', e); return null; } }
  async function updateServerPlayer(id,patch){ try{ const base = 'https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players/'+id; const mask = []; const bodyFields = {}; const local = players.find(p=> p.id===id); const missesVal = (patch.misses!==undefined) ? patch.misses : (local? (local.misses||0) : 0); if(patch.misses!==undefined || local){ bodyFields.misses = { integerValue: String(missesVal) }; mask.push('misses'); } if(patch.name!==undefined && String(patch.name).trim() !== ''){ bodyFields.name={ stringValue: String(patch.name) }; mask.push('name'); } if(patch.skill!==undefined && Number(patch.skill)>=1 && Number(patch.skill)<=9){ bodyFields.skill={ integerValue: String(patch.skill) }; mask.push('skill'); } if(local && local.createdAt){ bodyFields.createdAt = { integerValue: String(local.createdAt) }; if(!mask.includes('createdAt')) mask.push('createdAt'); } if(mask.length===0){ bodyFields.misses = { integerValue: String(missesVal) }; mask.push('misses'); } const url = base + '?key=' + API_KEY + mask.map(m=>'&updateMask.fieldPaths='+encodeURIComponent(m)).join(''); const res=await fetch(url,{ method:'PATCH', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ fields: bodyFields }) }); if(!res.ok){ const txt=await res.text(); throw new Error('update failed: '+res.status+' '+txt); } return true; }catch(e){ console.error('updateServerPlayer error', e); return false; } }
  async function deleteServerPlayer(id){ try{ const url='https://firestore.googleapis.com/v1/projects/'+PROJECT+'/databases/'+DB_ID+'/documents/players/'+id+'?key='+API_KEY; const res=await fetch(url,{ method:'DELETE' }); if(!res.ok){ const txt=await res.text(); throw new Error('delete failed: '+res.status+' '+txt); } return true; }catch(e){ console.error('deleteServerPlayer error', e); return false; } }

  // utility: total and charts (misses and amount)
  function updateTotalAndChart(){ const totalMisses = players.reduce((s,p)=> s + (p.misses||0), 0); const totalAmount = players.reduce((s,p)=> s + ((p.misses||0) * (p.skill||1)), 0); const totalMissesEl = document.getElementById('totalMisses'); const totalAmountEl = document.getElementById('totalAmount'); if(totalMissesEl) totalMissesEl.textContent = 'Total missed shots: ' + totalMisses; if(totalAmountEl) totalAmountEl.textContent = 'Total amount: $' + totalAmount; // charts
      try{
        const barLabelPlugin = { id: 'barValue', afterDatasetsDraw: function(chart){ const ctx = chart.ctx; const canvasWidth = chart.width; const isAmountChart = chart && chart.canvas && chart.canvas.id === 'chartAmount'; chart.data.datasets.forEach(function(dataset, i){ const meta = chart.getDatasetMeta(i); meta.data.forEach(function(bar, idx){ const val = dataset.data[idx]; if(val===undefined || val===null) return; const x = bar.x; const y = bar.y; ctx.save(); ctx.font = 'bold 12px Arial'; const displayVal = isAmountChart ? ('$' + String(val)) : String(val); const textWidth = ctx.measureText(displayVal).width; if(x + 20 + textWidth < canvasWidth){ ctx.fillStyle = '#111'; ctx.textAlign = 'left'; ctx.fillText(displayVal, x + 10, y); } else { ctx.fillStyle = '#fff'; ctx.textAlign = 'right'; ctx.fillText(displayVal, x - 8, y); } ctx.restore(); }); }); } };

        // unified soft palette: determine base order from list ordering so colors match across charts
        const compareOrder = (a,b)=>{ const ma=a.misses||0, mb=b.misses||0; if(mb - ma !== 0) return mb - ma; const ama=(a.misses||0)*(a.skill||1), amb=(b.misses||0)*(b.skill||1); if(amb - ama !== 0) return amb - ama; return (b.createdAt||0) - (a.createdAt||0); };
        const baseOrder = (players||[]).slice().sort(compareOrder);
        // generate soft pastel palette mapped by player id
        const paletteMap = {};
        if(baseOrder.length>0){ baseOrder.forEach((p,i)=>{ const hue = Math.round(i * 360 / baseOrder.length); paletteMap[p.id] = 'hsl(' + hue + ',55%,65%)'; }); }

        // Misses chart: use base order (full list)
        const missesSorted = baseOrder.slice();
        const labelsMisses = missesSorted.map(p=> p.name || 'Unnamed');
        const missesData = missesSorted.map(p=> p.misses||0);
        const paletteMisses = missesSorted.map(p=> paletteMap[p.id] || '#d1d5db');

        if(window.playerChartMisses){ window.playerChartMisses.data.labels = labelsMisses; window.playerChartMisses.data.datasets[0].data = missesData; window.playerChartMisses.data.datasets[0].backgroundColor = paletteMisses; window.playerChartMisses.update(); }
        else { const ctx = document.getElementById('chartMisses'); if(ctx && window.Chart){ window.playerChartMisses = new Chart(ctx.getContext('2d'), { type: 'bar', data: { labels: labelsMisses, datasets:[{ data: missesData, backgroundColor: paletteMisses }] }, options: { indexAxis: 'y', responsive:true, maintainAspectRatio:false, scales:{ x:{ beginAtZero:true } }, plugins:{ legend:{ display:false } } }, plugins: [barLabelPlugin] }); } }

        // Amount chart: rank by total $ and show top 4, reuse paletteMap so colors match same players
        const amountSorted = (players||[]).slice().sort((a,b)=> ((b.misses||0)*(b.skill||1)) - ((a.misses||0)*(a.skill||1)));
        const topAmount = amountSorted.slice(0,4);
        const labelsAmount = topAmount.map(p=> p.name || 'Unnamed');
        const amountData = topAmount.map(p=> (p.misses||0) * (p.skill||1));
        const paletteAmount = topAmount.map(p=> paletteMap[p.id] || '#d1d5db');

        if(window.playerChartAmount){ window.playerChartAmount.data.labels = labelsAmount; window.playerChartAmount.data.datasets[0].data = amountData; window.playerChartAmount.data.datasets[0].backgroundColor = paletteAmount; window.playerChartAmount.update(); }
        else { const ctx2 = document.getElementById('chartAmount'); if(ctx2 && window.Chart){ window.playerChartAmount = new Chart(ctx2.getContext('2d'), { type: 'bar', data: { labels: labelsAmount, datasets:[{ data: amountData, backgroundColor: paletteAmount }] }, options: { indexAxis: 'y', responsive:true, maintainAspectRatio:false, scales:{ x:{ beginAtZero:true } }, plugins:{ legend:{ display:false } } }, plugins: [barLabelPlugin] }); } }

    }catch(e){ console.error('chart update failed', e); }
  }

  // initial sync and poll (offline toggle removed)
  (async function init(){
    const server = await listServerPlayers();
    if(server===null){ setStatus('Firestore REST unreachable'); updateTotalAndChart(); } else {
      setStatus('connected to Firestore (REST)');
      const localOnly = players.filter(p=> String(p.id).startsWith('local-'));
      // merge server and local by id: prefer non-empty server.name, but keep local name if server name missing
      const byId = {};
      for(const l of players){ byId[l.id]=Object.assign({},l); }
      for(const s of server){ const existing = byId[s.id]; if(existing){ byId[s.id] = { id: s.id, name: (s.name && String(s.name).trim()) ? s.name : (existing.name || s.name), skill: (s.skill!==undefined) ? s.skill : (existing.skill||1), misses: (s.misses!==undefined)? s.misses : (existing.misses||0), createdAt: s.createdAt||existing.createdAt }; } else { byId[s.id] = Object.assign({}, s); } }
      players = Object.values(byId);
      // ensure local-only entries are preserved
      players = players.concat(localOnly.filter(p=> !players.find(x=>x.id===p.id)));
      saveLocal(players); render(players); updateTotalAndChart();
      for(const p of localOnly){ const newId = await createServerPlayer(p); if(newId){ players = players.map(x=> x.id===p.id? {...x, id:newId}: x); saveLocal(players); render(players); updateTotalAndChart(); } }
      if(typeof window !== 'undefined'){ setInterval(async ()=>{ // avoid clobbering inline edits while user is editing
                  if(typeof editingId !== 'undefined' && editingId !== null) { /* skip server merge while editing to preserve input state */ return; }
                  const s = await listServerPlayers(); if(s && Array.isArray(s)){ const localOnly2 = players.filter(p=> String(p.id).startsWith('local-'));
                  // merge same as above
                  const byId2 = {};
                  for(const l of players){ byId2[l.id]=Object.assign({},l); }
                  for(const ss of s){ const existing = byId2[ss.id]; if(existing){ byId2[ss.id] = { id: ss.id, name: (ss.name && String(ss.name).trim()) ? ss.name : (existing.name || ss.name), skill: (ss.skill!==undefined) ? ss.skill : (existing.skill||1), misses: (ss.misses!==undefined)? ss.misses : (existing.misses||0), createdAt: ss.createdAt||existing.createdAt }; } else { byId2[ss.id] = Object.assign({}, ss); } }
                  let merged = Object.values(byId2);
                  merged = merged.concat(localOnly2.filter(p=> !merged.find(x=>x.id===p.id)));
                  players = merged;
                  saveLocal(players); render(players); updateTotalAndChart(); setStatus('connected to Firestore (REST)'); } }, 2000); }
    }
  })();

  // server wrappers removed (offline toggle removed)
  // using direct REST helpers defined above (listServerPlayers/createServerPlayer/updateServerPlayer/deleteServerPlayer)

  // override push/update/delete functions to use REST
  function pushToFirestore(p){ return createServerPlayer(p); }
  function updateFirestore(id, patch){ return updateServerPlayer(id, patch); }
  function deleteFirestore(id){ return deleteServerPlayer(id); }

  // no-op for tryInit

})();